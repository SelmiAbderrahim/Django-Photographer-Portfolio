from django.contrib import admin
from .models import Images

admin.site.register(Images)
